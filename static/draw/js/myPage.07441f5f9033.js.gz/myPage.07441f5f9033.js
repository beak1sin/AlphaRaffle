$(document).ready(function() {
    $('#bookmark_tab, #checked_tab, #comment_tab, #setting_tab').click(function() {
        var targetID = $(this).attr('id');
        // console.log($(this).attr('id'));
        if (targetID == 'bookmark_tab') {
            if ($(this).hasClass('checked')) {
                return
            } else {
                $(this).addClass('checked');
                $('.bookmark-content').show();
                $('.checked-content').hide();
                $('.comment-content').hide();
                $('.setting-content').hide();
                $('.delete-content').hide();
                $('#delete_tab').hide();
                $('#checked_tab').removeClass('checked');
                $('#comment_tab').removeClass('checked');
                $('#setting_tab').removeClass('checked');
                $('#delete_tab').removeClass('checked');
            }
        } else if (targetID == 'checked_tab') {
            if ($(this).hasClass('checked')) {
                return
            } else {
                $(this).addClass('checked');
                $('.bookmark-content').hide();
                $('.checked-content').show();
                $('.comment-content').hide();
                $('.setting-content').hide();
                $('.delete-content').hide();
                $('#delete_tab').hide();
                $('#bookmark_tab').removeClass('checked');
                $('#comment_tab').removeClass('checked');
                $('#setting_tab').removeClass('checked');
                $('#delete_tab').removeClass('checked');
            }
        } else if (targetID == 'comment_tab') {
            if ($(this).hasClass('checked')) {
                return
            } else {
                $(this).addClass('checked');
                $('.bookmark-content').hide();
                $('.checked-content').hide();
                $('.comment-content').show();
                $('.setting-content').hide();
                $('.delete-content').hide();
                $('#delete_tab').hide();
                $('#bookmark_tab').removeClass('checked');
                $('#checked_tab').removeClass('checked');
                $('#setting_tab').removeClass('checked');
                $('#delete_tab').removeClass('checked');
            }
        } else if (targetID == 'setting_tab') {
            if ($(this).hasClass('checked')) {
                return
            } else {
                $(this).addClass('checked');
                $('.bookmark-content').hide();
                $('.checked-content').hide();
                $('.comment-content').hide();
                $('.setting-content').show();
                $('.delete-content').hide();
                $('#delete_tab').show();
                $('#bookmark_tab').removeClass('checked');
                $('#checked_tab').removeClass('checked');
                $('#comment_tab').removeClass('checked');
                $('#delete_tab').removeClass('checked');
            }
        }
    });

    $('#delete_tab').click(function() {
        $(this).addClass('checked');
        $('.bookmark-content').hide();
        $('.checked-content').hide();
        $('.comment-content').hide();
        $('.setting-content').hide();
        $('.delete-content').show();
        $('#bookmark_tab').removeClass('checked');
        $('#checked_tab').removeClass('checked');
        $('#comment_tab').removeClass('checked');
        $('#setting_tab').removeClass('checked');
    });
});

function getCookie(name) {
    var cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        var cookies = document.cookie.split(';');
        for (var i = 0; i < cookies.length; i++) {
            var cookie = jQuery.trim(cookies[i]);
            // Does this cookie string begin with the name we want?
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

var csrftoken = getCookie('csrftoken');

var xhr;

// 새로운 회원정보수정 방식
function updateMember() {
    membernickname = document.getElementById("member_nickname").value;
    if(membernickname == "") {
        document.getElementById("member_nickname").focus();
        return false;
    }

    memberphonenumber = document.getElementById("member_phonenumber").value;
    if(memberphonenumber == "") {
        document.getElementById("member_phonenumber").focus();
        return false;
    }

    membernikeid = document.getElementById("member_nikeid").value;
    if(membernikeid == "") {
        document.getElementById("member_nikeid").focus();
        return false;
    }

    memberbirth = document.getElementById("member_birth").value;
    if(memberbirth == "") {
        document.getElementById("member_birth").focus();
        return false;
    }


    var strurl = "member_update?member_nickname=" + membernickname + "&member_phonenumber=" + memberphonenumber + "&member_nikeid=" + membernikeid + "&member_birth=" + memberbirth;

    var data = { member_nickname: membernickname, member_phonenumber: memberphonenumber, member_nikeid: membernikeid, member_birth: memberbirth};
    var datastr = JSON.stringify(data);

    xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4) {
            var data = xhr.responseText;

            var obj = JSON.parse(data);
            alert(obj.result_msg);
            if(obj.flag == "0"){
                location.href = "/";
            }
        }
    };
    xhr.open("POST", "/auth/mypage/member_update");
    xhr.setRequestHeader("X-CSRFToken", csrftoken);
    xhr.send(datastr);
}