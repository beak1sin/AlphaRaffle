function dropped() {
    document.getElementById('section2').scrollIntoView({behavior: 'smooth'});
}

function getCookie(name) {
    var cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        var cookies = document.cookie.split(';');
        for (var i = 0; i < cookies.length; i++) {
            var cookie = jQuery.trim(cookies[i]);
            // Does this cookie string begin with the name we want?
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

var csrftoken = getCookie('csrftoken');

var xhr;

function detail() {

    serial = document.getElementById("serial").getAttribute('data-value');
    
    
    var data = { serialnum: serial};
    var datastr = JSON.stringify(data);


    xhr = new XMLHttpRequest();
    xhr.open("POST", "/auth/login/");
    xhr.setRequestHeader("X-CSRFToken", csrftoken);
    xhr.send(datastr);
}